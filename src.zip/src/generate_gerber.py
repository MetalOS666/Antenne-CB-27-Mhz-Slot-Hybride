#!/usr/bin/env python3
"""
Générateur de fichiers Gerber RS-274X pour JLCPCB
PCB Antenne CB Slot Hybride 27 MHz - 80x50mm simple face
Copyright InfoProject Software by Julien ARNOULD

Fichiers générés :
  - F.Cu (ou B.Cu pour simple face) : pistes cuivre
  - F.SilkS : sérigraphie face composants
  - F.Mask : masque de soudure
  - Edge.Cuts : contour de la carte
  - *.drl : fichier de perçage Excellon
"""

import math
import os
import zipfile
from datetime import datetime

# ============================================================
# PCB PARAMETERS
# ============================================================
BOARD_W = 80.0   # mm
BOARD_H = 50.0   # mm
CORNER_R = 1.0   # mm corner radius

# Mounting holes
MOUNT_MARGIN = 4.0
MOUNT_DRILL = 3.2  # M3
MOUNT_PAD = 6.0

# Pad sizes
PAD_DIA = 4.0
PAD_DRILL = 1.0
PAD_SQ = 4.0  # square pad size
PAD_SQ_DRILL = 1.0

# Trace widths
TRACE_SIGNAL = 1.0   # mm
TRACE_GND = 2.0      # mm
TRACE_POWER = 1.5    # mm

# ============================================================
# COMPONENT POSITIONS (mm from bottom-left origin)
# ============================================================

# Input pads (left side)
IN_A = (8.0, 38.0)    # Hot input
IN_B = (8.0, 12.0)    # Ground input

# C1 pads (near IN_A)
C1_1 = (18.0, 38.0)
C1_2 = (24.0, 38.0)

# C3 pads (near IN_B)
C3_1 = (18.0, 12.0)
C3_2 = (24.0, 12.0)

# Junction points
JUNC_HOT = (30.0, 38.0)
JUNC_GND = (30.0, 12.0)

# L1 pads (vertical)
L1_TOP = (35.0, 38.0)
L1_BOT = (35.0, 25.0)

# CV pads (variable capacitor - 3 pins top + 1 bottom)
CV_1 = (32.0, 22.0)   # left pin
CV_2 = (35.0, 22.0)   # center pin
CV_3 = (38.0, 22.0)   # right pin
CV_BOT = (35.0, 15.0)  # bottom connection

# Balun T1 pads (4 pads)
T1_PRI_TOP = (52.0, 38.0)   # Primary top
T1_PRI_BOT = (52.0, 12.0)   # Primary bottom
T1_SEC_TOP = (62.0, 38.0)   # Secondary top
T1_SEC_BOT = (62.0, 12.0)   # Secondary bottom

# Output pads (SO-239 area)
OUT_HOT = (72.0, 30.0)
OUT_GND = (72.0, 20.0)

# GND chassis pad
GND_PAD = (72.0, 8.0)

# Mounting holes
MOUNTS = [
    (MOUNT_MARGIN, MOUNT_MARGIN),
    (BOARD_W - MOUNT_MARGIN, MOUNT_MARGIN),
    (MOUNT_MARGIN, BOARD_H - MOUNT_MARGIN),
    (BOARD_W - MOUNT_MARGIN, BOARD_H - MOUNT_MARGIN),
]

# All through-hole pads
ROUND_PADS = [
    C1_1, C1_2, C3_1, C3_2,
    L1_TOP, L1_BOT,
    CV_1, CV_2, CV_3, CV_BOT,
    T1_PRI_TOP, T1_PRI_BOT, T1_SEC_TOP, T1_SEC_BOT,
]

SQUARE_PADS = [
    IN_A, IN_B, OUT_HOT, OUT_GND, GND_PAD,
]

# ============================================================
# TRACES (list of polylines as coordinate lists)
# ============================================================
TRACES_SIGNAL = [
    # Hot path: IN_A -> C1_1
    [IN_A, C1_1],
    # C1_2 -> JUNC_HOT
    [C1_2, JUNC_HOT],
    # JUNC_HOT -> L1_TOP
    [JUNC_HOT, L1_TOP],
    # L1_BOT -> CV_2 (center)
    [L1_BOT, CV_2],
    # CV_BOT -> down to GND level, across to JUNC_GND
    [CV_BOT, (35.0, 12.0), JUNC_GND],
    # JUNC_HOT -> T1 primary top
    [JUNC_HOT, (40.0, 38.0), T1_PRI_TOP],
    # Ground path: IN_B -> C3_1
    [IN_B, C3_1],
    # C3_2 -> JUNC_GND
    [C3_2, JUNC_GND],
    # JUNC_GND -> T1 primary bottom
    [JUNC_GND, (40.0, 12.0), T1_PRI_BOT],
    # T1 secondary top -> OUT_HOT
    [T1_SEC_TOP, (67.0, 38.0), (67.0, 30.0), OUT_HOT],
    # T1 secondary bottom -> OUT_GND
    [T1_SEC_BOT, (67.0, 12.0), (67.0, 20.0), OUT_GND],
]

TRACES_GND = [
    # Ground bus: JUNC_GND across to right side
    [JUNC_GND, (50.0, 12.0), (72.0, 12.0), GND_PAD],
    # OUT_GND down to ground bus
    [OUT_GND, (72.0, 12.0)],
]


# ============================================================
# GERBER GENERATION FUNCTIONS
# ============================================================

def gerber_header(layer_name):
    """Generate Gerber RS-274X header"""
    lines = []
    lines.append(f"%TF.GenerationSoftware,InfoProjectSoftware,CBSlotPCB,1.0*%")
    lines.append(f"%TF.CreationDate,{datetime.now().isoformat()}*%")
    lines.append(f"%TF.FileFunction,{layer_name}*%")
    lines.append("%FSLAX46Y46*%")  # Format: 4.6 leading zero suppression, absolute
    lines.append("%MOIN*%")  # Units: mm (actually we use MOMM)
    lines.append("%MOMM*%")  # Metric
    lines.append("%LPD*%")   # Layer polarity: dark
    return lines


def gerber_footer():
    return ["M02*"]


def fmt(val):
    """Format coordinate for Gerber (integer, 4.6 format = value * 1000000)"""
    return int(round(val * 1000000))


def aperture_circle(num, dia_mm):
    return f"%ADD{num}C,{dia_mm:.4f}*%"


def aperture_rect(num, w_mm, h_mm):
    return f"%ADD{num}R,{w_mm:.4f}X{h_mm:.4f}*%"


def flash_pad(x, y, aperture_num):
    return f"D{aperture_num}*\nX{fmt(x)}Y{fmt(y)}D03*"


def draw_line(x1, y1, x2, y2, aperture_num):
    lines = []
    lines.append(f"D{aperture_num}*")
    lines.append(f"X{fmt(x1)}Y{fmt(y1)}D02*")  # Move to start
    lines.append(f"X{fmt(x2)}Y{fmt(y2)}D01*")  # Draw to end
    return lines


def draw_polyline(points, aperture_num):
    """Draw connected line segments"""
    lines = []
    lines.append(f"D{aperture_num}*")
    x0, y0 = points[0]
    lines.append(f"X{fmt(x0)}Y{fmt(y0)}D02*")
    for x, y in points[1:]:
        lines.append(f"X{fmt(x)}Y{fmt(y)}D01*")
    return lines


def draw_arc_approx(cx, cy, radius, start_deg, end_deg, aperture_num, segments=32):
    """Approximate arc with line segments"""
    lines = []
    lines.append(f"D{aperture_num}*")
    angles = [start_deg + i * (end_deg - start_deg) / segments for i in range(segments + 1)]
    pts = [(cx + radius * math.cos(math.radians(a)), cy + radius * math.sin(math.radians(a))) for a in angles]
    x0, y0 = pts[0]
    lines.append(f"X{fmt(x0)}Y{fmt(y0)}D02*")
    for x, y in pts[1:]:
        lines.append(f"X{fmt(x)}Y{fmt(y)}D01*")
    return lines


def draw_rect_outline(x, y, w, h, aperture_num):
    """Draw rectangle outline"""
    lines = []
    pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h), (x, y)]
    lines.extend(draw_polyline(pts, aperture_num))
    return lines


def draw_text_gerber(text, x, y, height, aperture_num, spacing_factor=0.7):
    """
    Draw text using simple line-based font in Gerber.
    Returns list of Gerber commands.
    """
    lines = []
    char_width = height * 0.6
    char_spacing = char_width * spacing_factor + char_width
    
    # Simple vector font - each char is a list of strokes
    # Each stroke is a list of (rx, ry) relative points (0-1 range)
    font = define_simple_font()
    
    cx = x
    for ch in text.upper():
        if ch == ' ':
            cx += char_spacing * 0.5
            continue
        if ch in font:
            for stroke in font[ch]:
                pts = [(cx + p[0] * char_width, y + p[1] * height) for p in stroke]
                if len(pts) >= 2:
                    lines.append(f"D{aperture_num}*")
                    lines.append(f"X{fmt(pts[0][0])}Y{fmt(pts[0][1])}D02*")
                    for px, py in pts[1:]:
                        lines.append(f"X{fmt(px)}Y{fmt(py)}D01*")
        cx += char_spacing
    
    return lines


def define_simple_font():
    """Define a simple vector font for PCB silkscreen text"""
    f = {}
    # Letters as list of strokes, each stroke is list of (x,y) in 0-1 range
    f['A'] = [[(0,0),(0.5,1),(1,0)], [(0.2,0.4),(0.8,0.4)]]
    f['B'] = [[(0,0),(0,1),(0.7,1),(1,0.85),(1,0.7),(0.7,0.55),(0,0.55)], [(0.7,0.55),(1,0.4),(1,0.15),(0.7,0),(0,0)]]
    f['C'] = [[(1,0.85),(0.7,1),(0.3,1),(0,0.7),(0,0.3),(0.3,0),(0.7,0),(1,0.15)]]
    f['D'] = [[(0,0),(0,1),(0.6,1),(1,0.7),(1,0.3),(0.6,0),(0,0)]]
    f['E'] = [[(1,0),(0,0),(0,1),(1,1)], [(0,0.5),(0.7,0.5)]]
    f['F'] = [[(0,0),(0,1),(1,1)], [(0,0.5),(0.7,0.5)]]
    f['G'] = [[(1,0.85),(0.7,1),(0.3,1),(0,0.7),(0,0.3),(0.3,0),(0.7,0),(1,0.3),(1,0.5),(0.5,0.5)]]
    f['H'] = [[(0,0),(0,1)], [(1,0),(1,1)], [(0,0.5),(1,0.5)]]
    f['I'] = [[(0.3,0),(0.7,0)], [(0.5,0),(0.5,1)], [(0.3,1),(0.7,1)]]
    f['J'] = [[(0,0.3),(0.3,0),(0.7,0),(1,0.3),(1,1)]]
    f['K'] = [[(0,0),(0,1)], [(1,1),(0,0.5),(1,0)]]
    f['L'] = [[(0,1),(0,0),(1,0)]]
    f['M'] = [[(0,0),(0,1),(0.5,0.5),(1,1),(1,0)]]
    f['N'] = [[(0,0),(0,1),(1,0),(1,1)]]
    f['O'] = [[(0.3,0),(0,0.3),(0,0.7),(0.3,1),(0.7,1),(1,0.7),(1,0.3),(0.7,0),(0.3,0)]]
    f['P'] = [[(0,0),(0,1),(0.7,1),(1,0.85),(1,0.65),(0.7,0.5),(0,0.5)]]
    f['Q'] = [[(0.3,0),(0,0.3),(0,0.7),(0.3,1),(0.7,1),(1,0.7),(1,0.3),(0.7,0),(0.3,0)], [(0.6,0.3),(1,0)]]
    f['R'] = [[(0,0),(0,1),(0.7,1),(1,0.85),(1,0.65),(0.7,0.5),(0,0.5)], [(0.5,0.5),(1,0)]]
    f['S'] = [[(1,0.85),(0.7,1),(0.3,1),(0,0.85),(0,0.6),(0.3,0.5),(0.7,0.5),(1,0.4),(1,0.15),(0.7,0),(0.3,0),(0,0.15)]]
    f['T'] = [[(0,1),(1,1)], [(0.5,0),(0.5,1)]]
    f['U'] = [[(0,1),(0,0.3),(0.3,0),(0.7,0),(1,0.3),(1,1)]]
    f['V'] = [[(0,1),(0.5,0),(1,1)]]
    f['W'] = [[(0,1),(0.25,0),(0.5,0.5),(0.75,0),(1,1)]]
    f['X'] = [[(0,0),(1,1)], [(0,1),(1,0)]]
    f['Y'] = [[(0,1),(0.5,0.5),(1,1)], [(0.5,0.5),(0.5,0)]]
    f['Z'] = [[(0,1),(1,1),(0,0),(1,0)]]
    
    # Numbers
    f['0'] = f['O']
    f['1'] = [[(0.3,0.8),(0.5,1),(0.5,0)], [(0.2,0),(0.8,0)]]
    f['2'] = [[(0,0.85),(0.3,1),(0.7,1),(1,0.85),(1,0.6),(0,0),(1,0)]]
    f['3'] = [[(0,0.85),(0.3,1),(0.7,1),(1,0.85),(1,0.65),(0.7,0.5),(1,0.35),(1,0.15),(0.7,0),(0.3,0),(0,0.15)]]
    f['4'] = [[(0,1),(0,0.5),(1,0.5)], [(0.7,1),(0.7,0)]]
    f['5'] = [[(1,1),(0,1),(0,0.55),(0.7,0.55),(1,0.4),(1,0.15),(0.7,0),(0.3,0),(0,0.15)]]
    f['6'] = [[(0.7,1),(0.3,1),(0,0.7),(0,0.3),(0.3,0),(0.7,0),(1,0.3),(1,0.5),(0.7,0.55),(0,0.55)]]
    f['7'] = [[(0,1),(1,1),(0.3,0)]]
    f['8'] = [[(0.3,0.5),(0,0.65),(0,0.85),(0.3,1),(0.7,1),(1,0.85),(1,0.65),(0.7,0.5),(0.3,0.5),(0,0.35),(0,0.15),(0.3,0),(0.7,0),(1,0.15),(1,0.35),(0.7,0.5)]]
    f['9'] = [[(1,0.5),(0.3,0.45),(0,0.65),(0,0.85),(0.3,1),(0.7,1),(1,0.85),(1,0.3),(0.7,0),(0.3,0)]]
    
    # Symbols
    f['-'] = [[(0.2,0.5),(0.8,0.5)]]
    f['.'] = [[(0.4,0),(0.6,0),(0.6,0.1),(0.4,0.1),(0.4,0)]]
    f['/'] = [[(0,0),(1,1)]]
    f['('] = [[(0.7,1),(0.3,0.7),(0.3,0.3),(0.7,0)]]
    f[')'] = [[(0.3,1),(0.7,0.7),(0.7,0.3),(0.3,0)]]
    f[':'] = [[(0.4,0.7),(0.6,0.7),(0.6,0.8),(0.4,0.8),(0.4,0.7)], [(0.4,0.1),(0.6,0.1),(0.6,0.2),(0.4,0.2),(0.4,0.1)]]
    f['+'] = [[(0.5,0.2),(0.5,0.8)], [(0.2,0.5),(0.8,0.5)]]
    f['='] = [[(0.1,0.6),(0.9,0.6)], [(0.1,0.35),(0.9,0.35)]]
    f['©'] = [[(0.3,0),(0,0.3),(0,0.7),(0.3,1),(0.7,1),(1,0.7),(1,0.3),(0.7,0),(0.3,0)], [(0.7,0.65),(0.6,0.75),(0.4,0.75),(0.3,0.6),(0.3,0.4),(0.4,0.25),(0.6,0.25),(0.7,0.35)]]
    
    return f


# ============================================================
# GENERATE COPPER LAYER
# ============================================================
def generate_copper():
    lines = gerber_header("Copper,L1,Bot")
    
    # Define apertures
    lines.append(aperture_circle(10, TRACE_SIGNAL))   # D10: signal trace
    lines.append(aperture_circle(11, TRACE_GND))       # D11: ground trace
    lines.append(aperture_circle(12, TRACE_POWER))     # D12: power trace
    lines.append(aperture_circle(20, PAD_DIA))         # D20: round pad
    lines.append(aperture_rect(21, PAD_SQ, PAD_SQ))   # D21: square pad
    lines.append(aperture_circle(22, MOUNT_PAD))       # D22: mounting pad
    lines.append(aperture_circle(15, 0.2))             # D15: thin trace for text
    
    # Flash mounting hole pads
    for mx, my in MOUNTS:
        lines.append(flash_pad(mx, my, 22))
    
    # Flash round pads
    for px, py in ROUND_PADS:
        lines.append(flash_pad(px, py, 20))
    
    # Flash square pads
    for px, py in SQUARE_PADS:
        lines.append(flash_pad(px, py, 21))
    
    # Draw signal traces
    for trace in TRACES_SIGNAL:
        lines.extend(draw_polyline(trace, 10))
    
    # Draw ground traces (wider)
    for trace in TRACES_GND:
        lines.extend(draw_polyline(trace, 11))
    
    # Ground fill zone (simplified as hatched lines in bottom area)
    # Draw a ground zone border
    gnd_zone = [
        (28.0, 7.0), (75.0, 7.0), (75.0, 14.0), (28.0, 14.0), (28.0, 7.0)
    ]
    lines.extend(draw_polyline(gnd_zone, 11))
    
    # Fill with horizontal traces
    for gy_int in range(8, 14):
        gy = float(gy_int)
        lines.extend(draw_polyline([(29.0, gy), (74.0, gy)], 11))
    
    lines.extend(gerber_footer())
    return "\n".join(lines)


# ============================================================
# GENERATE SILKSCREEN LAYER
# ============================================================
def generate_silkscreen():
    lines = gerber_header("Legend,Top")
    
    # Apertures for silkscreen
    lines.append(aperture_circle(10, 0.2))    # D10: thin outline
    lines.append(aperture_circle(11, 0.15))   # D11: text
    lines.append(aperture_circle(12, 0.25))   # D12: thick outline
    
    # Component outlines
    
    # C1 outline
    lines.extend(draw_rect_outline(C1_1[0] - 1, C1_1[1] - 2.5, 
                                    C1_2[0] - C1_1[0] + 2, 5.0, 10))
    lines.extend(draw_text_gerber("C1", C1_1[0], C1_1[1] + 3.5, 2.0, 11))
    
    # C3 outline
    lines.extend(draw_rect_outline(C3_1[0] - 1, C3_1[1] - 2.5,
                                    C3_2[0] - C3_1[0] + 2, 5.0, 10))
    lines.extend(draw_text_gerber("C3", C3_1[0], C3_1[1] + 3.5, 2.0, 11))
    
    # L1 outline (taller rectangle)
    lines.extend(draw_rect_outline(L1_TOP[0] - 4, L1_BOT[1] - 2,
                                    8.0, L1_TOP[1] - L1_BOT[1] + 4, 10))
    lines.extend(draw_text_gerber("L1", L1_TOP[0] - 3, L1_TOP[1] + 3, 2.0, 11))
    
    # CV outline (circle)
    lines.extend(draw_arc_approx(35.0, 18.5, 6.0, 0, 360, 10))
    lines.extend(draw_text_gerber("CV", 30.0, 24.5, 2.0, 11))
    
    # T1 Balun outline (large circle for tore)
    t1_cx = (T1_PRI_TOP[0] + T1_SEC_TOP[0]) / 2
    t1_cy = (T1_PRI_TOP[1] + T1_PRI_BOT[1]) / 2
    lines.extend(draw_arc_approx(t1_cx, t1_cy, 9.0, 0, 360, 10))
    lines.extend(draw_text_gerber("T1", t1_cx - 4, t1_cy + 11, 2.0, 11))
    lines.extend(draw_text_gerber("4:1", t1_cx - 3, t1_cy - 2, 1.8, 11))
    
    # SO-239 outline
    lines.extend(draw_arc_approx(OUT_HOT[0], 25.0, 6.0, 0, 360, 10))
    lines.extend(draw_text_gerber("J1", OUT_HOT[0] - 2, OUT_HOT[1] + 5, 2.0, 11))
    
    # Input labels
    lines.extend(draw_text_gerber("IN A", 3.0, IN_A[1] + 4, 1.8, 11))
    lines.extend(draw_text_gerber("HOT", 4.0, IN_A[1] - 4, 1.5, 11))
    lines.extend(draw_text_gerber("IN B", 3.0, IN_B[1] + 4, 1.8, 11))
    lines.extend(draw_text_gerber("GND", 4.0, IN_B[1] - 4, 1.5, 11))
    
    # Output label
    lines.extend(draw_text_gerber("SO-239", 66.0, 33.0, 1.5, 11))
    lines.extend(draw_text_gerber("50 OHM", 66.0, 17.0, 1.5, 11))
    
    # GND chassis label
    lines.extend(draw_text_gerber("GND", 68.0, 5.0, 1.8, 11))
    
    # Title block
    lines.extend(draw_rect_outline(15.0, 20.0, 20.0, 12.0, 10))
    lines.extend(draw_text_gerber("CB SLOT", 16.0, 28.0, 2.2, 11))
    lines.extend(draw_text_gerber("27 MHZ", 16.0, 24.5, 2.2, 11))
    lines.extend(draw_text_gerber("V1.0", 18.0, 21.0, 1.5, 11))
    
    # Copyright text (bottom of board)
    lines.extend(draw_text_gerber("COPYRIGHT INFOPROJECT SOFTWARE", 5.0, 1.5, 1.2, 11))
    lines.extend(draw_text_gerber("BY JULIEN ARNOULD", 20.0, -0.5, 1.2, 11))
    # Actually put it inside board area
    # Clear previous and redo at y=3.0 and y=1.2
    
    lines.extend(gerber_footer())
    
    # Fix: regenerate with copyright inside board
    return "\n".join(lines)


def generate_silkscreen_v2():
    lines = gerber_header("Legend,Top")
    
    lines.append(aperture_circle(10, 0.2))
    lines.append(aperture_circle(11, 0.15))
    lines.append(aperture_circle(12, 0.25))
    
    # Component outlines
    lines.extend(draw_rect_outline(C1_1[0] - 1, C1_1[1] - 2.5, C1_2[0] - C1_1[0] + 2, 5.0, 10))
    lines.extend(draw_text_gerber("C1", C1_1[0] + 1, C1_1[1] + 3.5, 2.0, 11))
    lines.extend(draw_text_gerber("100P", C1_1[0] - 0.5, C1_1[1] - 5.5, 1.3, 11))
    
    lines.extend(draw_rect_outline(C3_1[0] - 1, C3_1[1] - 2.5, C3_2[0] - C3_1[0] + 2, 5.0, 10))
    lines.extend(draw_text_gerber("C3", C3_1[0] + 1, C3_1[1] + 3.5, 2.0, 11))
    lines.extend(draw_text_gerber("100P", C3_1[0] - 0.5, C3_1[1] - 5.5, 1.3, 11))
    
    lines.extend(draw_rect_outline(L1_TOP[0] - 4, L1_BOT[1] - 2, 8.0, L1_TOP[1] - L1_BOT[1] + 4, 10))
    lines.extend(draw_text_gerber("L1", L1_TOP[0] + 5, L1_TOP[1] - 5, 2.0, 11))
    lines.extend(draw_text_gerber("1-5UH", L1_TOP[0] + 5, L1_TOP[1] - 8, 1.3, 11))
    
    lines.extend(draw_arc_approx(35.0, 18.5, 6.0, 0, 360, 10))
    lines.extend(draw_text_gerber("CV", 29.0, 10.0, 2.0, 11))
    lines.extend(draw_text_gerber("10-150P", 25.0, 7.5, 1.3, 11))
    
    t1_cx = (T1_PRI_TOP[0] + T1_SEC_TOP[0]) / 2
    t1_cy = (T1_PRI_TOP[1] + T1_PRI_BOT[1]) / 2
    lines.extend(draw_arc_approx(t1_cx, t1_cy, 9.0, 0, 360, 10))
    lines.extend(draw_text_gerber("T1 BALUN", t1_cx - 7, t1_cy + 11, 1.8, 11))
    lines.extend(draw_text_gerber("4:1", t1_cx - 2.5, t1_cy - 1.5, 2.0, 11))
    lines.extend(draw_text_gerber("FT140-43", t1_cx - 6, t1_cy - 12, 1.3, 11))
    
    lines.extend(draw_arc_approx(OUT_HOT[0], 25.0, 6.0, 0, 360, 10))
    lines.extend(draw_text_gerber("J1", OUT_HOT[0] - 2, 32.0, 2.0, 11))
    lines.extend(draw_text_gerber("SO239", 66.5, 17.5, 1.5, 11))
    
    lines.extend(draw_text_gerber("IN-A", 3.0, IN_A[1] + 4, 1.8, 11))
    lines.extend(draw_text_gerber("IN-B", 3.0, IN_B[1] + 4, 1.8, 11))
    
    lines.extend(draw_text_gerber("GND", 68.0, 4.5, 1.8, 11))
    
    # Title block
    lines.extend(draw_rect_outline(10.0, 19.0, 18.0, 14.0, 10))
    lines.extend(draw_text_gerber("CB SLOT", 11.0, 29.0, 2.0, 11))
    lines.extend(draw_text_gerber("27MHZ", 12.0, 25.5, 2.0, 11))
    lines.extend(draw_text_gerber("V1.0", 14.0, 22.0, 1.5, 11))
    lines.extend(draw_text_gerber("2026", 14.0, 20.0, 1.3, 11))
    
    # Copyright - at bottom, inside board area  
    lines.extend(draw_text_gerber("(C) INFOPROJECT SOFTWARE", 8.0, 3.0, 1.3, 11))
    lines.extend(draw_text_gerber("BY JULIEN ARNOULD", 14.0, 1.0, 1.3, 11))
    
    lines.extend(gerber_footer())
    return "\n".join(lines)


# ============================================================
# GENERATE SOLDER MASK LAYER
# ============================================================
def generate_soldermask():
    lines = gerber_header("Soldermask,Bot")
    
    # Apertures (slightly larger than pads for mask opening)
    mask_expansion = 0.2
    lines.append(aperture_circle(20, PAD_DIA + mask_expansion))
    lines.append(aperture_rect(21, PAD_SQ + mask_expansion, PAD_SQ + mask_expansion))
    lines.append(aperture_circle(22, MOUNT_PAD + mask_expansion))
    
    # Flash openings for all pads
    for mx, my in MOUNTS:
        lines.append(flash_pad(mx, my, 22))
    
    for px, py in ROUND_PADS:
        lines.append(flash_pad(px, py, 20))
    
    for px, py in SQUARE_PADS:
        lines.append(flash_pad(px, py, 21))
    
    lines.extend(gerber_footer())
    return "\n".join(lines)


# ============================================================
# GENERATE EDGE CUTS (BOARD OUTLINE)
# ============================================================
def generate_edge_cuts():
    lines = gerber_header("Profile,NP")
    
    lines.append(aperture_circle(10, 0.1))  # Thin line for outline
    
    # Rectangle with rounded corners
    r = CORNER_R
    w = BOARD_W
    h = BOARD_H
    
    # Bottom edge (left to right)
    lines.extend(draw_polyline([(r, 0), (w - r, 0)], 10))
    # Bottom-right corner
    lines.extend(draw_arc_approx(w - r, r, r, 270, 360, 10, 8))
    # Right edge
    lines.extend(draw_polyline([(w, r), (w, h - r)], 10))
    # Top-right corner
    lines.extend(draw_arc_approx(w - r, h - r, r, 0, 90, 10, 8))
    # Top edge
    lines.extend(draw_polyline([(w - r, h), (r, h)], 10))
    # Top-left corner
    lines.extend(draw_arc_approx(r, h - r, r, 90, 180, 10, 8))
    # Left edge
    lines.extend(draw_polyline([(0, h - r), (0, r)], 10))
    # Bottom-left corner
    lines.extend(draw_arc_approx(r, r, r, 180, 270, 10, 8))
    
    lines.extend(gerber_footer())
    return "\n".join(lines)


# ============================================================
# GENERATE DRILL FILE (EXCELLON)
# ============================================================
def generate_drill():
    lines = []
    lines.append("M48")
    lines.append(";DRILL file generated by InfoProject Software")
    lines.append(";TYPE=plated")
    lines.append(";FORMAT={-:-/ absolute / metric / decimal}")
    lines.append("FMAT,2")
    lines.append("METRIC,TZ")
    
    # Tool definitions
    lines.append(f"T1C{PAD_DRILL:.3f}")      # Component holes
    lines.append(f"T2C{MOUNT_DRILL:.3f}")     # Mounting holes
    lines.append(f"T3C{PAD_SQ_DRILL:.3f}")    # Square pad holes
    
    lines.append("%")
    
    # T1 - Component pad holes
    lines.append("T1")
    for px, py in ROUND_PADS:
        lines.append(f"X{px:.3f}Y{py:.3f}")
    
    # T2 - Mounting holes
    lines.append("T2")
    for mx, my in MOUNTS:
        lines.append(f"X{mx:.3f}Y{my:.3f}")
    
    # T3 - Square pad holes (connectors)
    lines.append("T3")
    for px, py in SQUARE_PADS:
        lines.append(f"X{px:.3f}Y{py:.3f}")
    
    lines.append("M30")  # End of file
    
    return "\n".join(lines)


# ============================================================
# GENERATE PASTE LAYER (empty but needed by JLCPCB)
# ============================================================
def generate_paste():
    lines = gerber_header("Paste,Bot")
    lines.extend(gerber_footer())
    return "\n".join(lines)


# ============================================================
# MAIN - Generate all files and create ZIP
# ============================================================
def main():
    output_dir = "/home/claude/gerber_cb_slot"
    os.makedirs(output_dir, exist_ok=True)
    
    files = {
        "CB_Slot_27MHz-B_Cu.gbr": generate_copper(),
        "CB_Slot_27MHz-F_SilkS.gbr": generate_silkscreen_v2(),
        "CB_Slot_27MHz-B_Mask.gbr": generate_soldermask(),
        "CB_Slot_27MHz-Edge_Cuts.gbr": generate_edge_cuts(),
        "CB_Slot_27MHz-B_Paste.gbr": generate_paste(),
        "CB_Slot_27MHz.drl": generate_drill(),
    }
    
    # Write individual files
    for fname, content in files.items():
        fpath = os.path.join(output_dir, fname)
        with open(fpath, 'w') as f:
            f.write(content)
        print(f"  Créé : {fname}")
    
    # Create ZIP for JLCPCB upload
    zip_path = "/home/claude/CB_Slot_27MHz_JLCPCB.zip"
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for fname in files:
            fpath = os.path.join(output_dir, fname)
            zf.write(fpath, fname)
    
    print(f"\n  ZIP JLCPCB créé : {zip_path}")
    print(f"  Fichiers inclus : {len(files)}")
    print(f"\n  Spécifications PCB :")
    print(f"    Dimensions : {BOARD_W} x {BOARD_H} mm")
    print(f"    Couches : 1 (simple face)")
    print(f"    Matériau : FR4 1.6mm")
    print(f"    Cuivre : 1oz (35um)")
    print(f"    Finition : HASL")
    print(f"    Trous : {len(ROUND_PADS)} x {PAD_DRILL}mm + {len(MOUNTS)} x {MOUNT_DRILL}mm + {len(SQUARE_PADS)} x {PAD_SQ_DRILL}mm")
    print(f"    Copyright : InfoProject Software by Julien ARNOULD")

if __name__ == "__main__":
    main()
